import { defineConfig } from 'astro/config';

// https://astro.build/config
export default defineConfig({
  site: 'https://danilaz06.github.io',
  // Si despliegas en GitHub Pages como repo project, descomenta:
  // base: '/portfolio',
  build: {
    inlineStylesheets: 'auto',
  },
});
